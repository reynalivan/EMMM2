archived mod fixture
